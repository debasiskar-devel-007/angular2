"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require('@angular/core');
var forms_1 = require('@angular/forms');
//import {FORM_DIRECTIVES, REACTIVE_FORM_DIRECTIVES} from '@angular/forms';
var router_1 = require('@angular/router');
var http_1 = require("@angular/http");
var app_commonservices_1 = require('../../services/app.commonservices');
var core_2 = require('angular2-cookie/core');
var AppAddadmin = (function () {
    function AppAddadmin(fb, http, commonservices, userInfo, router) {
        var _this = this;
        this.items = commonservices.getItems();
        this.http = http;
        this.router = router;
        this.userInfo = userInfo;
        console.log(this.items);
        console.log(this.items[0].serverUrl);
        this.serverUrl = this.items[0].serverUrl;
        this.http.get(this.serverUrl + 'getusastates')
            .subscribe(function (data) {
            console.log(data);
            _this.getusastates = data.json();
            console.log(_this.getusastates);
        }, function (error) {
            console.log("Oooops!");
        });
        this.addadminform = fb.group({
            username: ["", forms_1.Validators.required],
            password: ["", forms_1.Validators.required],
            fname: ["", forms_1.Validators.required],
            lname: ["", forms_1.Validators.required],
            email: ["", AppAddadmin.validateEmail],
            address: ["", forms_1.Validators.required],
            city: ["", forms_1.Validators.required],
            state: ["", forms_1.Validators.required],
            phone: ["", forms_1.Validators.required],
            zip: ["", forms_1.Validators.required],
            is_active: [""]
        });
        //this.router.navigate(['/about']);
    }
    AppAddadmin.validateTerms = function (control) {
        if (control.value == false) {
            return { 'isTermsChecked': true };
        }
    };
    AppAddadmin.validateEmail = function (control) {
        console.log('34324324');
        console.log(control.value);
        if (control.value == '' || !control.value.match(/[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?/)) {
            return { 'invalidEmailAddress': true };
        }
        //let appsignupobj=new AppSignup();
        // /console.log(appsignupobj.signupform.value.term);
    };
    AppAddadmin.prototype.submitform = function () {
        var _this = this;
        var x;
        for (x in this.addadminform.controls) {
            this.addadminform.controls[x].markAsTouched();
        }
        console.log(this.addadminform.dirty);
        this.addadminform.markAsDirty();
        if (this.addadminform.valid) {
            //var headers = new Headers();
            //headers.append('Content-Type', 'application/x-www-form-urlencoded');
            //this.items = this.commonservices.getItems();
            var link = this.serverUrl + 'addadmin';
            var submitdata = this.addadminform.value;
            this.http.post(link, submitdata)
                .subscribe(function (data) {
                // /this.data1.response = data.json();
                _this.router.navigateByUrl('/adminlist(adminheader:adminheader//adminfooter:adminfooter)');
            }, function (error) {
                console.log("Oooops!");
            });
        }
    };
    AppAddadmin.prototype.allroute = function () {
        this.router.navigateByUrl('/signup(dealerheader:dealerheader//dealerfooter:dealerfooter)');
    };
    AppAddadmin.prototype.godashboard = function () {
        this.router.navigateByUrl('/dealerdashboard(dealerheader:dealerheader//dealerfooter:dealerfooter)');
    };
    AppAddadmin = __decorate([
        core_1.Component({
            selector: 'my-app',
            //template: '<h1>Welcome to my First Angular 2 App </h1>'
            templateUrl: 'app/pages/addadmin/home.html',
            providers: [app_commonservices_1.AppCommonservices]
        }), 
        __metadata('design:paramtypes', [forms_1.FormBuilder, http_1.Http, app_commonservices_1.AppCommonservices, core_2.CookieService, router_1.Router])
    ], AppAddadmin);
    return AppAddadmin;
}());
exports.AppAddadmin = AppAddadmin;
//# sourceMappingURL=app.addadmin.js.map