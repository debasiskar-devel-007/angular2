"use strict";
var router_1 = require('@angular/router');
var app_contact_1 = require('./pages/contact/app.contact');
var app_about_1 = require('./pages/about/app.about');
var app_signup_1 = require('./pages/signup/app.signup');
var app_customersignup_1 = require('./pages/customersignup/app.customersignup');
var app_creditcard_1 = require('./pages/creditcard/app.creditcard');
var app_dealerlogin_1 = require("./pages/dealerlogin/app.dealerlogin");
var app_dealerheader_1 = require("./pages/dealerheader/app.dealerheader");
var app_dealerfooter_1 = require("./pages/dealerfooter/app.dealerfooter");
var app_dealerdashboard_1 = require("./pages/dealerdashboard/app.dealerdashboard");
var app_adminlogin_1 = require("./pages/adminlogin/app.adminlogin");
var app_customerlogin_1 = require("./pages/customerlogin/app.customerlogin");
var app_adminheader_1 = require("./pages/adminheader/app.adminheader");
var app_adminfooter_1 = require("./pages/adminfooter/app.adminfooter");
var app_admindashboard_1 = require("./pages/admindashboard/app.admindashboard");
var app_customerdashboard_1 = require("./pages/customerdashboard/app.customerdashboard");
var app_addadmin_1 = require("./pages/addadmin/app.addadmin");
var app_editadmin_1 = require("./pages/editadmin/app.editadmin");
var app_addfaq_1 = require("./pages/addfaq/app.addfaq");
var app_addfaqbyadmin_1 = require("./pages/addfaqbyadmin/app.addfaqbyadmin");
var app_editfaqbyadmin_1 = require("./pages/editfaqbyadmin/app.editfaqbyadmin");
var app_adminlist_1 = require("./pages/adminlist/app.adminlist");
var app_faq_1 = require("./pages/faq/app.faq");
var app_faqs_1 = require("./pages/dealerfaq/app.faqs");
var app_customercreditcard_1 = require("./pages/customercreditcard/app.customercreditcard");
var app_customerheader_1 = require('./pages/customerheader/app.customerheader');
//alert(window.location.hostname);
var checkutl = app_adminlogin_1.AppAdminlogin;
//alert(checkutl);
if (window.location.hostname == 'probidtech.influxiq.com') {
    var checkutl_1 = app_adminlogin_1.AppAdminlogin;
}
if (window.location.hostname == 'probiddealer.influxiq.com') {
    var checkutl_2 = app_signup_1.AppSignup;
}
if (window.location.hostname == 'probidcustomer.influxiq.com') {
    var checkutl_3 = app_customersignup_1.AppCustomersignup;
}
if (window.location.hostname == 'localhost') {
    var checkutl_4 = app_signup_1.AppSignup;
}
var appRoutes = [
    // { path: '/**',component: AppComponent},
    //{ path: '/*',component: AppComponent},
    { path: 'contact', component: app_contact_1.AppContact },
    { path: 'about', component: app_about_1.AppAbout },
    { path: '', component: checkutl },
    { path: 'signup', component: app_signup_1.AppSignup },
    { path: 'creditcard', component: app_creditcard_1.AppCreditcard },
    { path: 'dealerlogin', component: app_dealerlogin_1.AppDealerlogin },
    { path: 'dealerfooter', component: app_dealerfooter_1.AppDealerfooter, outlet: 'dealerfooter' },
    { path: 'dealerheader', component: app_dealerheader_1.AppDealerheader, outlet: 'dealerheader' },
    { path: 'dealerdashboard', component: app_dealerdashboard_1.AppDealerdashboard },
    { path: 'customersignup', component: app_customersignup_1.AppCustomersignup },
    { path: 'customercreditcard', component: app_customercreditcard_1.AppCustomercreditcard },
    { path: 'adminlogin', component: app_adminlogin_1.AppAdminlogin },
    { path: 'customerlogin', component: app_customerlogin_1.AppCustomerlogin },
    { path: 'adminheader', component: app_adminheader_1.AppAdminheader, outlet: 'adminheader' },
    { path: 'customerheader', component: app_customerheader_1.AppCustomerheader, outlet: 'customerheader' },
    { path: 'adminfooter', component: app_adminfooter_1.AppAdminfooter, outlet: 'adminfooter' },
    { path: 'admindashboard', component: app_admindashboard_1.AppAdmindashboard },
    { path: 'customerdashboard', component: app_customerdashboard_1.AppCustomerdashboard },
    { path: 'addadmin', component: app_addadmin_1.AppAddadmin },
    { path: 'addfaq', component: app_addfaq_1.AppAddfaq },
    { path: 'addfaqbyadmin', component: app_addfaqbyadmin_1.AppAddFaqByAdmin },
    { path: 'adminlist', component: app_adminlist_1.AppAdminlist },
    { path: 'faq', component: app_faq_1.AppFaq },
    { path: 'dealerfaq', component: app_faqs_1.AppDealerFaq },
    { path: 'editadmin/:id', component: app_editadmin_1.AppEditadmin },
    { path: 'editfaq/:id', component: app_editfaqbyadmin_1.AppEditFaqbyAdmin },
];
exports.appRoutingProviders = [];
exports.routing = router_1.RouterModule.forRoot(appRoutes, { useHash: true });
//# sourceMappingURL=contacts.routes.js.map