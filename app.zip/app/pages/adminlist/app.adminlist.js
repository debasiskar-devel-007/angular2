"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require('@angular/core');
var forms_1 = require('@angular/forms');
var router_1 = require('@angular/router');
var http_1 = require("@angular/http");
var app_commonservices_1 = require('../../services/app.commonservices');
var core_2 = require('angular2-cookie/core');
var app_component_1 = require("../home/app.component");
var AppAdminlist = (function () {
    function AppAdminlist(fb, http, commonservices, userInfo, router, appcomponent) {
        var _this = this;
        this.router = router;
        this.http = http;
        this.router = router;
        this.appcomponent = appcomponent;
        this.commonservices = commonservices;
        this.items = commonservices.getItems();
        this.messages = appcomponent.getMessages();
        console.log(this.messages);
        this.serverUrl = this.items[0].serverUrl;
        var link = this.serverUrl + 'adminlist';
        this.p = 1;
        this.orderbyquery = 'fname';
        this.orderbytype = -1;
        // alert(link);
        this.http.get(link)
            .subscribe(function (data1) {
            _this.data = data1.json();
            // this.router.navigateByUrl('/adminlist(adminheader:adminheader//adminfooter:adminfooter)')
            console.log(_this.data);
            _this.pagec = Math.ceil(_this.data.length / 10);
        }, function (error) {
            console.log("Oooops!");
        });
    }
    AppAdminlist.prototype.addadmin = function () {
        this.router.navigateByUrl('/addadmin(adminheader:adminheader//adminfooter:adminfooter)');
    };
    AppAdminlist.prototype.deleterow = function (adminid) {
        //console.log(adminid);
        var _this = this;
        var link = this.serverUrl + 'deleteadmin';
        var id = adminid;
        this.http.post(link, id)
            .subscribe(function (data1) {
            // this.data = data1.json();
            //  this.router.navigateByUrl('/adminlist(adminheader:adminheader//adminfooter:adminfooter)');
            var index = _this.data.indexOf(id.id);
            console.log(index);
            //let tempdata:Array<any>;
            var x;
            for (x in _this.data) {
                console.log(_this.data[x]._id);
                console.log('this.data[x]._id');
                console.log(adminid._id);
                if (adminid._id == _this.data[x]._id) {
                    console.log(x + '.......' + _this.data.length);
                    delete _this.data.x;
                    _this.data.splice(x, 1);
                    console.log(_this.data.length);
                    //this.router.navigate(['adminlist']);
                    window.location.reload();
                }
            }
            console.log(_this.data);
            //this.data=this.tempdata;
            //this.data.splice(index, 1);
            _this.appcomponent.putmessages('Admin user ' + adminid.username + ' deleted successfully', 'success');
            //console.log(this.data);
        }, function (error) {
            console.log("Oooops!");
        });
        // this.router.navigateByUrl('/adminlist(adminheader:adminheader//adminfooter:adminfooter)');
    };
    AppAdminlist.prototype.changeStatus = function (item) {
        var _this = this;
        var idx = this.data.indexOf(item);
        if (this.data[idx].is_active == 1) {
            var is_active = 0;
        }
        else {
            var is_active = 1;
        }
        var stat = { id: item._id, is_active: is_active };
        var link = this.serverUrl + 'adminstatuschange';
        this.http.post(link, stat)
            .subscribe(function (data1) {
            // this.data = data1.json();
            //  this.router.navigateByUrl('/adminlist(adminheader:adminheader//adminfooter:adminfooter)');
            if (_this.data[idx].is_active == 0) {
                _this.data[idx].is_active = 1;
            }
            else {
                _this.data[idx].is_active = 0;
            }
        }, function (error) {
            console.log("Oooops!");
        });
    };
    AppAdminlist.prototype.getSortClass = function (value) {
        console.log(value);
        if (this.orderbyquery == value && this.orderbytype == -1) {
            console.log('caret-up');
            return 'caret-up';
        }
        if (this.orderbyquery == value && this.orderbytype == 1) {
            console.log('caret-up');
            return 'caret-down';
        }
        return 'caret-up-down';
    };
    AppAdminlist.prototype.manageSorting = function (value) {
        console.log(value);
        if (this.orderbyquery == value && this.orderbytype == -1) {
            this.orderbytype = 1;
            return;
        }
        if (this.orderbyquery == value && this.orderbytype == 1) {
            this.orderbytype = -1;
            return;
        }
        this.orderbyquery = value;
        this.orderbytype = -1;
    };
    AppAdminlist = __decorate([
        core_1.Component({
            selector: 'my-app',
            //template: '<h1>Welcome to my First Angular 2 App </h1>'
            templateUrl: 'app/pages/adminlist/home.html',
            providers: [app_commonservices_1.AppCommonservices]
        }), 
        __metadata('design:paramtypes', [forms_1.FormBuilder, http_1.Http, app_commonservices_1.AppCommonservices, core_2.CookieService, router_1.Router, app_component_1.AppComponent])
    ], AppAdminlist);
    return AppAdminlist;
}());
exports.AppAdminlist = AppAdminlist;
//# sourceMappingURL=app.adminlist.js.map