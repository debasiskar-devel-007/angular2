"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require('@angular/core');
var forms_1 = require('@angular/forms');
//import {FORM_DIRECTIVES, REACTIVE_FORM_DIRECTIVES} from '@angular/forms';
var router_1 = require('@angular/router');
var http_1 = require("@angular/http");
var app_commonservices_1 = require('../../services/app.commonservices');
var core_2 = require('angular2-cookie/core');
var AppSignup = (function () {
    function AppSignup(fb, http, commonservices, userInfo, router) {
        this.items = commonservices.getItems();
        this.http = http;
        this.router = router;
        this.userInfo = userInfo;
        console.log(this.items);
        console.log(this.items[0].serverUrl);
        this.serverUrl = this.items[0].serverUrl;
        this.signupform = fb.group({
            username: ["", forms_1.Validators.required],
            password: ["", forms_1.Validators.required],
            fname: ["", forms_1.Validators.required],
            lname: ["", forms_1.Validators.required],
            email: ["", AppSignup.validateEmail],
            phone: ["", forms_1.Validators.required],
            zip: ["", forms_1.Validators.required],
            term: ["", AppSignup.validateTerms]
        });
        //this.router.navigate(['/about']);
    }
    AppSignup.validateTerms = function (control) {
        console.log('34324324');
        console.log(control.value);
        if (control.value == false) {
            return { 'isTermsChecked': true };
        }
        //let appsignupobj=new AppSignup();
        // /console.log(appsignupobj.signupform.value.term);
    };
    AppSignup.validateEmail = function (control) {
        console.log('34324324');
        console.log(control.value);
        if (control.value == '' || !control.value.match(/[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?/)) {
            return { 'invalidEmailAddress': true };
        }
        //let appsignupobj=new AppSignup();
        // /console.log(appsignupobj.signupform.value.term);
    };
    AppSignup.prototype.submitform = function () {
        var _this = this;
        //this.signupform.set;
        var x;
        console.log(this.signupform.value.term);
        for (x in this.signupform.controls) {
            this.signupform.controls[x].markAsTouched();
        }
        console.log(this.signupform.dirty);
        this.signupform.markAsDirty();
        //this.signupform.controls['fname'].markAsTouched();
        console.log(this.signupform.dirty);
        console.log(this.signupform.valid);
        console.log(this.signupform.errors);
        if (this.signupform.valid) {
            //var headers = new Headers();
            //headers.append('Content-Type', 'application/x-www-form-urlencoded');
            //this.items = this.commonservices.getItems();
            var link = this.serverUrl + 'adddealer';
            var submitdata = this.signupform.value;
            console.log(this.items);
            this.http.post(link, submitdata)
                .subscribe(function (data) {
                // /this.data1.response = data.json();
                console.log(data);
                _this.signupform.value.password = '';
                _this.userInfo.putObject('userInfo', _this.signupform.value);
                //console.log(this.userInfo.getObject('userInfo'));
                _this.router.navigate(['/creditcard']);
                //this.local = new Storage(LocalStorageService);
                // this.local.set('userinfo', JSON.stringify(data.json()));
                //console.logthis.local.get('userinfo');
            }, function (error) {
                console.log("Oooops!");
            });
        }
    };
    AppSignup.prototype.allroute = function () {
        this.router.navigateByUrl('/signup(dealerheader:dealerheader//dealerfooter:dealerfooter)');
    };
    AppSignup.prototype.godashboard = function () {
        this.router.navigateByUrl('/dealerdashboard(dealerheader:dealerheader//dealerfooter:dealerfooter)');
    };
    AppSignup = __decorate([
        core_1.Component({
            selector: 'my-app',
            //template: '<h1>Welcome to my First Angular 2 App </h1>'
            templateUrl: 'app/pages/signup/home.html',
            providers: [app_commonservices_1.AppCommonservices]
        }), 
        __metadata('design:paramtypes', [forms_1.FormBuilder, http_1.Http, app_commonservices_1.AppCommonservices, core_2.CookieService, router_1.Router])
    ], AppSignup);
    return AppSignup;
}());
exports.AppSignup = AppSignup;
//# sourceMappingURL=app.signup.js.map