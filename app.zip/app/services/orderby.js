/*
 * Example use
 *		Basic Array of single type: *ngFor="#todo of todoService.todos | orderBy : '-'"
 *		Multidimensional Array Sort on single column: *ngFor="#todo of todoService.todos | orderBy : ['-status']"
 *		Multidimensional Array Sort on multiple columns: *ngFor="#todo of todoService.todos | orderBy : ['status', '-title']"
 */
"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require('@angular/core');
var OrderBy = (function () {
    function OrderBy() {
    }
    OrderBy.prototype.transform = function (array, args, type) {
        console.log('aa');
        console.log(array);
        console.log(args);
        console.log(type);
        //array.sort(dynamicSort(args));
        if (typeof (array) != 'undefined') {
            array.sort(function (a, b) {
                //console.log(args);
                //console.log(type);
                //console.log(a[args]);
                var nameA = a[args].toString().toLowerCase(), nameB = b[args].toString().toLowerCase();
                if (nameA < nameB)
                    if (!type || type == 1)
                        return -1;
                    else
                        return 1;
                if (nameA > nameB)
                    if (!type || type == 1)
                        return 1;
                    else
                        return -1; //default return value (no sorting)
            });
            return array;
        }
        return array;
    };
    OrderBy = __decorate([
        core_1.Pipe({
            name: 'orderBy'
        }), 
        __metadata('design:paramtypes', [])
    ], OrderBy);
    return OrderBy;
}());
exports.OrderBy = OrderBy;
function dynamicSort(property) {
    var sortOrder = 1;
    if (property[0] === "-") {
        sortOrder = -1;
        property = property.substr(1);
    }
    return function (a, b) {
        var result = (a[property] < b[property]) ? -1 : (a[property] > b[property]) ? 1 : 0;
        return result * sortOrder;
    };
}
//# sourceMappingURL=orderby.js.map