"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require('@angular/core');
var forms_1 = require('@angular/forms');
//import {FORM_DIRECTIVES, REACTIVE_FORM_DIRECTIVES} from '@angular/forms';
var router_1 = require('@angular/router');
var http_1 = require("@angular/http");
var app_commonservices_1 = require('../../services/app.commonservices');
var core_2 = require('angular2-cookie/core');
var AppCustomersignup = (function () {
    function AppCustomersignup(fb, http, commonservices, customerInfo, router) {
        this.items = commonservices.getItems();
        this.http = http;
        this.router = router;
        this.customerInfo = customerInfo;
        console.log(this.items);
        console.log(this.items[0].serverUrl);
        this.serverUrl = this.items[0].serverUrl;
        this.customersignupform = fb.group({
            username: ["", forms_1.Validators.required],
            password: ["", forms_1.Validators.required],
            fname: ["", forms_1.Validators.required],
            lname: ["", forms_1.Validators.required],
            email: ["", AppCustomersignup.validateEmail],
            phone: ["", forms_1.Validators.required],
            zip: ["", forms_1.Validators.required],
            term: ["", AppCustomersignup.validateTerms]
        });
    }
    AppCustomersignup.validateTerms = function (control) {
        if (control.value == false) {
            return { 'isTermsChecked': true };
        }
    };
    AppCustomersignup.validateEmail = function (control) {
        if (control.value == '' || !control.value.match(/[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?/)) {
            return { 'invalidEmailAddress': true };
        }
    };
    AppCustomersignup.prototype.submitform = function () {
        var _this = this;
        var x;
        for (x in this.customersignupform.controls) {
            this.customersignupform.controls[x].markAsTouched();
        }
        this.customersignupform.markAsDirty();
        //this.signupform.controls['fname'].markAsTouched();
        if (this.customersignupform.valid) {
            var link = this.serverUrl + 'addcustomer';
            var submitdata = this.customersignupform.value;
            this.http.post(link, submitdata)
                .subscribe(function (data) {
                // /this.data1.response = data.json();
                _this.customersignupform.value.password = '';
                _this.customerInfo.putObject('customerInfo', _this.customersignupform.value);
                _this.router.navigate(['/customercreditcard']);
            }, function (error) {
                console.log("Oooops!");
            });
        }
    };
    AppCustomersignup = __decorate([
        core_1.Component({
            selector: 'my-app',
            //template: '<h1>Welcome to my First Angular 2 App </h1>'
            templateUrl: 'app/pages/customersignup/home.html',
            providers: [app_commonservices_1.AppCommonservices]
        }), 
        __metadata('design:paramtypes', [forms_1.FormBuilder, http_1.Http, app_commonservices_1.AppCommonservices, core_2.CookieService, router_1.Router])
    ], AppCustomersignup);
    return AppCustomersignup;
}());
exports.AppCustomersignup = AppCustomersignup;
//# sourceMappingURL=app.customersignup.js.map