"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require('@angular/core');
var forms_1 = require('@angular/forms');
//import {FORM_DIRECTIVES, REACTIVE_FORM_DIRECTIVES} from '@angular/forms';
var router_1 = require('@angular/router');
var http_1 = require("@angular/http");
var app_commonservices_1 = require('../../services/app.commonservices');
var core_2 = require('angular2-cookie/core');
var AppAdminlogin = (function () {
    function AppAdminlogin(fb, http, commonservices, userdetails, router) {
        this.items = commonservices.getItems();
        this.serverUrl = this.items[0].serverUrl;
        this.userdetails = userdetails;
        this.userDetails = userdetails.getObject('userdetails');
        this.http = http;
        this.router = router;
        this.adminloginform = fb.group({
            //term: ["", AppCreditcard.validateTerms]
            username: ["", forms_1.Validators.required],
            password: ["", forms_1.Validators.required]
        });
        if (typeof (this.userDetails) != 'undefined') {
            this.router.navigateByUrl('/admindashboard(adminheader:adminheader//adminfooter:adminfooter)');
            return;
        }
    }
    AppAdminlogin.prototype.submitform = function () {
        var _this = this;
        //this.signupform.set;
        var x;
        //     console.log(this.dealerloginform.value.term);
        for (x in this.adminloginform.controls) {
            this.adminloginform.controls[x].markAsTouched();
        }
        // console.log(this.dealerloginform.dirty);
        this.adminloginform.markAsDirty();
        //this.signupform.controls['fname'].markAsTouched();
        if (this.adminloginform.valid) {
            var link = this.serverUrl + 'admincheck';
            var submitdata = this.adminloginform.value;
            this.http.post(link, submitdata)
                .subscribe(function (data) {
                // this.data1.response = data.json();
                console.log(data.json());
                var res = data.json();
                if (res.length > 0) {
                    console.log();
                    var userdet = { username: res[0].username, useremail: res[0].email, userrole: 'admin', userfullname: res[0].fname + ' ' + res[0].lname };
                    console.log('Login successfully');
                    _this.userdetails.putObject('userdetails', userdet);
                    _this.loginerror = 1;
                    _this.router.navigateByUrl('/admindashboard(adminheader:adminheader//adminfooter:adminfooter)');
                }
                else {
                    console.log('UsernameInvalid username/password');
                    _this.loginerror = 0;
                }
            }, function (error) {
                console.log("Oooops!");
            });
        }
    };
    AppAdminlogin.prototype.goadmindashboard = function () {
        this.router.navigateByUrl('/admindashboard(adminheader:adminheader//adminfooter:adminfooter)');
    };
    AppAdminlogin.prototype.addadmin = function () {
        this.router.navigateByUrl('/addadmin(adminheader:adminheader//adminfooter:adminfooter)');
    };
    AppAdminlogin = __decorate([
        core_1.Component({
            selector: 'my-app',
            //template: '<h1>Welcome to my First Angular 2 App </h1>'
            templateUrl: 'app/pages/adminlogin/home.html',
            providers: [app_commonservices_1.AppCommonservices]
        }), 
        __metadata('design:paramtypes', [forms_1.FormBuilder, http_1.Http, app_commonservices_1.AppCommonservices, core_2.CookieService, router_1.Router])
    ], AppAdminlogin);
    return AppAdminlogin;
}());
exports.AppAdminlogin = AppAdminlogin;
//# sourceMappingURL=app.adminlogin.js.map