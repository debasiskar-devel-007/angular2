"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require('@angular/core');
var contacts_routes_1 = require('./contacts.routes');
var platform_browser_1 = require('@angular/platform-browser');
var app_component_1 = require('./pages/home/app.component');
var app_home_1 = require('./pages/home/app.home');
var app_about_1 = require('./pages/about/app.about');
var app_signup_1 = require('./pages/signup/app.signup');
var app_signupcomponent_1 = require('./pages/signup/app.signupcomponent');
var app_customersignup_1 = require('./pages/customersignup/app.customersignup');
var app_creditcard_1 = require('./pages/creditcard/app.creditcard');
var http_1 = require('@angular/http');
var ng2_popover_1 = require("ng2-popover");
var cookies_service_1 = require('angular2-cookie/services/cookies.service');
var search_pipe_1 = require('./services/search.pipe');
var orderby_1 = require('./services/orderby');
var app_contact_1 = require('./pages/contact/app.contact');
var forms_1 = require("@angular/forms");
var ng2_modal_1 = require("ng2-modal");
var app_dealerlogincomponent_1 = require("./pages/dealerlogin/app.dealerlogincomponent");
var app_dealerlogin_1 = require("./pages/dealerlogin/app.dealerlogin");
var app_dealerheader_1 = require("./pages/dealerheader/app.dealerheader");
var app_dealerfooter_1 = require("./pages/dealerfooter/app.dealerfooter");
var app_dealerdashboard_1 = require("./pages/dealerdashboard/app.dealerdashboard");
var app_adminlogin_1 = require("./pages/adminlogin/app.adminlogin");
var app_adminlogincomponent_1 = require('./pages/adminlogin/app.adminlogincomponent');
var app_customerlogin_1 = require("./pages/customerlogin/app.customerlogin");
var app_customerlogincomponent_1 = require('./pages/customerlogin/app.customerlogincomponent');
var app_adminheader_1 = require('./pages/adminheader/app.adminheader');
var app_customerheader_1 = require('./pages/customerheader/app.customerheader');
var app_adminfooter_1 = require('./pages/adminfooter/app.adminfooter');
var app_admindashboard_1 = require('./pages/admindashboard/app.admindashboard');
var app_customerdashboard_1 = require('./pages/customerdashboard/app.customerdashboard');
var app_addadmin_1 = require('./pages/addadmin/app.addadmin');
var app_editadmin_1 = require('./pages/editadmin/app.editadmin');
var app_addfaq_1 = require('./pages/addfaq/app.addfaq');
var app_editfaqbyadmin_1 = require('./pages/editfaqbyadmin/app.editfaqbyadmin');
var app_addfaqbyadmin_1 = require('./pages/addfaqbyadmin/app.addfaqbyadmin');
var app_adminlist_1 = require('./pages/adminlist/app.adminlist');
var app_faq_1 = require('./pages/faq/app.faq');
var app_faqs_1 = require('./pages/dealerfaq/app.faqs');
var app_customercreditcard_1 = require('./pages/customercreditcard/app.customercreditcard');
var ng2_pagination_1 = require('ng2-pagination');
var ng2_ckeditor_1 = require('ng2-ckeditor');
var AppModule = (function () {
    function AppModule() {
    }
    AppModule = __decorate([
        core_1.NgModule({
            imports: [platform_browser_1.BrowserModule, forms_1.FormsModule, forms_1.ReactiveFormsModule, contacts_routes_1.routing, http_1.HttpModule,
                http_1.JsonpModule, ng2_modal_1.ModalModule, ng2_popover_1.PopoverModule, ng2_pagination_1.Ng2PaginationModule, ng2_ckeditor_1.CKEditorModule],
            declarations: [app_component_1.AppComponent, app_adminheader_1.AppAdminheader, app_adminfooter_1.AppAdminfooter, app_admindashboard_1.AppAdmindashboard, app_adminlist_1.AppAdminlist, app_addadmin_1.AppAddadmin, app_contact_1.AppContact, app_about_1.AppAbout, app_home_1.AppHome, app_signup_1.AppSignup, app_signupcomponent_1.AppSignupComponents, app_creditcard_1.AppCreditcard, app_dealerlogincomponent_1.AppdealerloginComponents, app_dealerlogin_1.AppDealerlogin, app_dealerheader_1.AppDealerheader, app_dealerfooter_1.AppDealerfooter, app_dealerdashboard_1.AppDealerdashboard, app_customersignup_1.AppCustomersignup, app_customercreditcard_1.AppCustomercreditcard, app_adminlogin_1.AppAdminlogin, app_adminlogincomponent_1.AppadminloginComponents, app_customerlogin_1.AppCustomerlogin, app_customerlogincomponent_1.AppcustomerloginComponents, app_addfaq_1.AppAddfaq, app_faq_1.AppFaq, app_editadmin_1.AppEditadmin, search_pipe_1.searchPipe, orderby_1.OrderBy, app_addfaqbyadmin_1.AppAddFaqByAdmin, app_editfaqbyadmin_1.AppEditFaqbyAdmin, app_faqs_1.AppDealerFaq, app_customerheader_1.AppCustomerheader, app_customerdashboard_1.AppCustomerdashboard],
            providers: [
                contacts_routes_1.appRoutingProviders, cookies_service_1.CookieService
            ],
            bootstrap: [app_component_1.AppComponent]
        }), 
        __metadata('design:paramtypes', [])
    ], AppModule);
    return AppModule;
}());
exports.AppModule = AppModule;
//# sourceMappingURL=app.module.js.map