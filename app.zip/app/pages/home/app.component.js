"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require('@angular/core');
var forms_1 = require('@angular/forms');
var app_commonservices_1 = require('../../services/app.commonservices');
var http_1 = require("@angular/http");
var cookies_service_1 = require("angular2-cookie/services/cookies.service");
var AppComponent = (function () {
    function AppComponent(fb, commonservices, http, cookeiservice) {
        this.firstName = new forms_1.FormControl("", forms_1.Validators.required);
        this.items = commonservices.getItems();
        console.log(this.items);
        console.log(this.items[0].serverUrl);
        this.cookeiservice = cookeiservice;
        var wikiUrl = this.items[0].serverUrl + 'listexpert';
        http.get(wikiUrl)
            .subscribe(function (data) {
            // /this.data1.response = data.json();
            console.log(data);
        }, function (error) {
            console.log("Oooops!");
        });
        this.loginForm = fb.group({
            email: ["", forms_1.Validators.required],
            password: ["", forms_1.Validators.required]
        });
    }
    AppComponent.prototype.doLogin = function () {
        //console.log(this.loginForm.value);
        console.log(99);
        alert(67);
        console.log(this.loginForm.value);
        console.log(this.loginForm.value.email);
    };
    AppComponent.prototype.getMessages = function () {
        var messages = this.cookeiservice.getObject('cmessages');
        this.cookeiservice.remove('cmessages');
        if (typeof (messages) != 'undefined') {
            if (messages.type == 'success')
                return '<p class="bg-success">' + messages.message + '</p>';
            if (messages.type == 'warning')
                return '<p class="bg-warning">' + messages.message + '</p>';
            if (messages.type == 'error')
                return '<p class="bg-danger">' + messages.message + '</p>';
        }
        return '';
    };
    AppComponent.prototype.putmessages = function (message, type) {
        //let messages:Array<any>;
        console.log(typeof (this.cookeiservice.getObject('cmessages')));
        console.log(this.cookeiservice.getObject('cmessages'));
        if (typeof (this.cookeiservice.getObject('cmessages')) == 'undefined') {
            console.log('un');
            var mval = { message: message, type: type };
            var messages = void 0;
            messages = mval;
            this.cookeiservice.putObject('cmessages', messages);
        }
        else {
            console.log('yes');
            var messages = this.cookeiservice.getObject('cmessages');
            var mval = { message: message, type: type };
            messages[Math.random().toString().replace('.', '') + Math.random().toString().replace('.', '')] = mval;
            this.cookeiservice.putObject('cmessages', messages);
        }
    };
    AppComponent = __decorate([
        core_1.Component({
            selector: 'my-app',
            /*
                template: '<router-outlet></router-outlet>',
            */
            template: '<router-outlet name="dealerheader"><router-outlet name="customerheader">' +
                '</router-outlet><router-outlet name="adminheader"></router-outlet><router-outlet></router-outlet><router-outlet name="dealerfooter"></router-outlet><router-outlet name="adminfooter"><router-outlet name="customerfooter"></router-outlet>',
            providers: [app_commonservices_1.AppCommonservices]
        }), 
        __metadata('design:paramtypes', [forms_1.FormBuilder, app_commonservices_1.AppCommonservices, http_1.Http, cookies_service_1.CookieService])
    ], AppComponent);
    return AppComponent;
}());
exports.AppComponent = AppComponent;
//# sourceMappingURL=app.component.js.map