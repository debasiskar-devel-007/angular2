"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require('@angular/core');
var forms_1 = require('@angular/forms');
var http_1 = require("@angular/http");
var app_commonservices_1 = require('../../services/app.commonservices');
var core_2 = require('angular2-cookie/core');
var AppCustomercreditcard = (function () {
    function AppCustomercreditcard(fb, http, commonservices, customerInfo) {
        var _this = this;
        this.items = commonservices.getItems();
        this.getExpyears = commonservices.getExpyears();
        this.expMonths = commonservices.getMonths();
        //this.getusastates = commonservices.getusastates();
        this.customerinfo = customerInfo.getObject('customerInfo');
        this.http = http;
        this.serverUrl = this.items[0].serverUrl;
        this.http.get(this.serverUrl + 'getusastates')
            .subscribe(function (data) {
            console.log(data);
            _this.getusastates = data.json();
            console.log(_this.getusastates);
        }, function (error) {
            console.log("Oooops!");
        });
        this.customercreditform = fb.group({
            username: [this.customerinfo.username, forms_1.Validators.required],
            address: ["", forms_1.Validators.required],
            state: ["", forms_1.Validators.required],
            expmonth: ["", forms_1.Validators.required],
            city: ["", forms_1.Validators.required],
            expyear: ["", forms_1.Validators.required],
            ccno: ["", forms_1.Validators.required],
            cvv: ["", forms_1.Validators.required],
            fname: [this.customerinfo.fname, forms_1.Validators.required],
            lname: [this.customerinfo.lname, forms_1.Validators.required],
            email: [this.customerinfo.email, AppCustomercreditcard.validateEmail],
            phone: [this.customerinfo.phone, forms_1.Validators.required],
            zip: [this.customerinfo.zip, forms_1.Validators.required],
        });
    }
    AppCustomercreditcard.validateTerms = function (control) {
        console.log('34324324');
        console.log(control.value);
        if (control.value == false) {
            return { 'isTermsChecked': true };
        }
    };
    AppCustomercreditcard.validateEmail = function (control) {
        if (control.value == '' || !control.value.match(/[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?/)) {
            return { 'invalidEmailAddress': true };
        }
    };
    AppCustomercreditcard.validateState = function (control) {
        console.log(control.value + 'stateval');
        if (control.value == '') {
            return { 'invalidState': true };
        }
    };
    AppCustomercreditcard.prototype.submitform = function () {
        var x;
        for (x in this.customercreditform.controls) {
            this.customercreditform.controls[x].markAsTouched();
        }
        this.customercreditform.markAsDirty();
        //this.signupform.controls['fname'].markAsTouched();
        if (this.customercreditform.valid) {
            //var headers = new Headers();
            //headers.append('Content-Type', 'application/x-www-form-urlencoded');
            //this.items = this.commonservices.getItems();
            var link = this.serverUrl + 'updatecustomer';
            var submitdata = this.customercreditform.value;
            console.log(link);
            this.http.post(link, submitdata)
                .subscribe(function (data) {
                // /this.data1.response = data.json();
                console.log(data[0]);
            }, function (error) {
                console.log("Oooops!");
            });
        }
    };
    AppCustomercreditcard = __decorate([
        core_1.Component({
            selector: 'my-app',
            //template: '<h1>Welcome to my First Angular 2 App </h1>'
            templateUrl: 'app/pages/customercreditcard/home.html',
            providers: [app_commonservices_1.AppCommonservices]
        }), 
        __metadata('design:paramtypes', [forms_1.FormBuilder, http_1.Http, app_commonservices_1.AppCommonservices, core_2.CookieService])
    ], AppCustomercreditcard);
    return AppCustomercreditcard;
}());
exports.AppCustomercreditcard = AppCustomercreditcard;
//# sourceMappingURL=app.customercreditcard.js.map