"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require('@angular/core');
var forms_1 = require('@angular/forms');
//import {FORM_DIRECTIVES, REACTIVE_FORM_DIRECTIVES} from '@angular/forms';
var router_1 = require('@angular/router');
var http_1 = require("@angular/http");
var app_commonservices_1 = require('../../services/app.commonservices');
var core_2 = require('angular2-cookie/core');
var app_component_1 = require("../home/app.component");
var AppDealerFaq = (function () {
    function AppDealerFaq(fb, http, commonservices, userdetails, router, appcomponent) {
        var _this = this;
        this.router = router;
        this.http = http;
        this.router = router;
        this.items = commonservices.getItems();
        this.serverUrl = this.items[0].serverUrl;
        this.p = 1;
        this.userInfo = userdetails.getObject('userdetails');
        var link = '';
        if (this.userInfo.userrole == 'dealer')
            link = this.serverUrl + 'dealerfaqlist?dealerid=' + this.userInfo.username;
        if (this.userInfo.userrole == 'customer')
            link = this.serverUrl + 'dealerfaqlist?dealerid=customer';
        this.orderbyquery = 'added_on';
        this.orderbytype = -1;
        this.http.get(link)
            .subscribe(function (data1) {
            _this.data = data1.json();
            // this.router.navigateByUrl('/adminlist(adminheader:adminheader//adminfooter:adminfooter)')
            console.log(_this.data.length);
            _this.pagec = Math.ceil(_this.data.length / 10);
        }, function (error) {
            console.log("Oooops!");
        });
        // alert(link);
    }
    AppDealerFaq.prototype.faq = function () {
        this.router.navigateByUrl('/faq(adminheader:adminheader//adminfooter:adminfooter)');
    };
    AppDealerFaq.prototype.updatefaqstatus = function (val, item) {
        var _this = this;
        console.log(this.userInfo);
        console.log(this.userInfo.userrole);
        var link1 = this.serverUrl + 'updatefaqstatus?is_system=0&type=' + this.userInfo.userrole + '&id=' + item._id + '&value=' + val;
        //this.p=1;
        this.http.get(link1)
            .subscribe(function (data2) {
            _this.data = data2.json();
            // this.router.navigateByUrl('/adminlist(adminheader:adminheader//adminfooter:adminfooter)')
            //console.log(this.data);
            _this.pagec = Math.ceil(_this.data.length / 10);
        }, function (error) {
            console.log("Oooops!");
        });
    };
    AppDealerFaq.prototype.deletefaq = function (adminid) {
        //console.log(adminid);
        var _this = this;
        var link = this.serverUrl + 'deletefaq';
        var id = adminid;
        this.http.post(link, id)
            .subscribe(function (data1) {
            // this.data = data1.json();
            //  this.router.navigateByUrl('/adminlist(adminheader:adminheader//adminfooter:adminfooter)');
            var index = _this.data.indexOf(id.id);
            console.log(index);
            //let tempdata:Array<any>;
            var x;
            for (x in _this.data) {
                console.log(_this.data[x]._id);
                console.log('this.data[x]._id');
                console.log(adminid._id);
                if (adminid._id == _this.data[x]._id) {
                    console.log(x + '.......' + _this.data.length);
                    delete _this.data.x;
                    _this.data.splice(x, 1);
                    console.log(_this.data.length);
                    //this.router.navigate(['adminlist']);
                    window.location.reload();
                }
            }
            console.log(_this.data);
            //this.data=this.tempdata;
            //this.data.splice(index, 1);
            _this.appcomponent.putmessages('Faq ' + adminid.title + ' deleted successfully', 'success');
            //console.log(this.data);
        }, function (error) {
            console.log("Oooops!");
        });
        // this.router.navigateByUrl('/adminlist(adminheader:adminheader//adminfooter:adminfooter)');
    };
    AppDealerFaq = __decorate([
        core_1.Component({
            selector: 'my-app',
            //template: '<h1>Welcome to my First Angular 2 App </h1>'
            templateUrl: 'app/pages/faq/home.html',
            providers: [app_commonservices_1.AppCommonservices]
        }), 
        __metadata('design:paramtypes', [forms_1.FormBuilder, http_1.Http, app_commonservices_1.AppCommonservices, core_2.CookieService, router_1.Router, app_component_1.AppComponent])
    ], AppDealerFaq);
    return AppDealerFaq;
}());
exports.AppDealerFaq = AppDealerFaq;
//# sourceMappingURL=app.faqs.js.map